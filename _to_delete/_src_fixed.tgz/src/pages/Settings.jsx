import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import UpdateChecker from '../components/UpdateChecker';
import { supabase } from '../supabase';
import { Settings as SettingsIcon, Lock, ShieldCheck, Key, AlertCircle, Loader2, FileText, Database, History, Globe, RefreshCw, Download, Cloud } from 'lucide-react';
import toast from 'react-hot-toast';

const Settings = () => {
    const { user } = useSelector(state => state.auth);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [terminalPin, setTerminalPin] = useState(localStorage.getItem('tahzeeb_terminal_pin') || '1234');
    const [activeTab, setActiveTab] = useState('security');
    const [isLoading, setIsLoading] = useState(false);

    const handlePasswordChange = async (e) => {
        e.preventDefault();

        if (newPassword !== confirmPassword) {
            toast.error("New passwords do not match!");
            return;
        }

        if (newPassword.length < 6) {
            toast.error("Password must be at least 6 characters.");
            return;
        }

        setIsLoading(true);
        try {
            const { error } = await supabase.auth.updateUser({ password: newPassword });

            if (error) throw error;

            toast.success("Password updated successfully in Supabase!");
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } catch (error) {
            console.error(error);
            toast.error(error.message || "Failed to update password.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleUpdatePin = (e) => {
        e.preventDefault();
        if (terminalPin.length !== 4) {
            toast.error("PIN must be exactly 4 digits!");
            return;
        }
        localStorage.setItem('tahzeeb_terminal_pin', terminalPin);
        toast.success("Terminal Security PIN updated!");
    };

    return (
        <div style={{ maxWidth: '1000px', margin: '0 auto', height: '100%', display: 'flex', flexDirection: 'column', gap: '20px', padding: window.innerWidth <= 768 ? '10px' : '20px', overflowY: 'auto' }}>
            <header style={{ background: 'white', padding: '25px', borderRadius: '16px', border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
                <div>
                    <h2 style={{ fontSize: window.innerWidth <= 480 ? '1.2rem' : '1.8rem', fontWeight: 950, color: '#1e293b' }}>SYSTEM SETUP</h2>
                    <p style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: 600 }}>Manage security, terminal locks, and view software documentation.</p>
                </div>
                <div style={{ background: '#0f172a', color: 'white', padding: '12px', borderRadius: '12px' }}>
                    <SettingsIcon size={28} />
                </div>
            </header>

            <div style={{
                display: 'flex',
                flexDirection: window.innerWidth <= 768 ? 'column' : 'row',
                gap: '20px',
                flex: 1
            }}>
                {/* Side Navigation */}
                <div style={{
                    padding: '15px',
                    minWidth: window.innerWidth <= 768 ? '100%' : '280px',
                    background: 'white',
                    borderRadius: '16px',
                    border: '1px solid #e2e8f0',
                    height: 'fit-content',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px'
                }}>
                    <button
                        onClick={() => setActiveTab('security')}
                        style={{ width: '100%', padding: '14px', background: activeTab === 'security' ? '#eff6ff' : 'transparent', border: 'none', borderRadius: '10px', color: activeTab === 'security' ? '#2563eb' : '#64748b', fontWeight: 800, textAlign: 'left', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', transition: '0.2s' }}
                    >
                        <Lock size={18} />
                        Security Settings
                    </button>
                    <button
                        onClick={() => setActiveTab('backup')}
                        style={{ width: '100%', padding: '14px', background: activeTab === 'backup' ? '#f0fdf4' : 'transparent', border: 'none', borderRadius: '10px', color: activeTab === 'backup' ? '#16a34a' : '#64748b', fontWeight: 800, textAlign: 'left', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', transition: '0.2s' }}
                    >
                        <Database size={18} />
                        Cloud Registry Backup
                    </button>
                    <button
                        onClick={() => setActiveTab('audit')}
                        style={{ width: '100%', padding: '14px', background: activeTab === 'audit' ? '#fff7ed' : 'transparent', border: 'none', borderRadius: '10px', color: activeTab === 'audit' ? '#ea580c' : '#64748b', fontWeight: 800, textAlign: 'left', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', transition: '0.2s' }}
                    >
                        <History size={18} />
                        System Activity Log
                    </button>
                    <button
                        onClick={() => setActiveTab('docs')}
                        style={{ width: '100%', padding: '14px', background: activeTab === 'docs' ? '#f5f3ff' : 'transparent', border: 'none', borderRadius: '10px', color: activeTab === 'docs' ? '#7c3aed' : '#64748b', fontWeight: 800, textAlign: 'left', display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer', transition: '0.2s' }}
                    >
                        <ShieldCheck size={18} />
                        Software Documentation
                    </button>

                    <div style={{ marginTop: '30px' }}>
                        <UpdateChecker />
                    </div>
                </div>

                {/* Main Content */}
                <div style={{
                    background: 'white',
                    borderRadius: '16px',
                    border: '1px solid #e2e8f0',
                    flex: 1,
                    padding: window.innerWidth <= 480 ? '20px' : '40px',
                    boxShadow: '0 10px 15px -3px rgba(0,0,0,0.02)'
                }}>
                    {activeTab === 'security' ? (
                        <>
                            <div style={{ marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
                                <h3 style={{ fontSize: '1.2rem', fontWeight: 900, color: '#1e293b', marginBottom: '8px' }}>Change Access Password</h3>
                                <p style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: 600 }}>Update your terminal login credentials. Re-authentication will be required.</p>
                            </div>

                            <form onSubmit={handlePasswordChange} style={{ display: 'flex', flexDirection: 'column', gap: '25px' }}>
                                <div>
                                    <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 900, color: '#475569', textTransform: 'uppercase', marginBottom: '10px' }}>Current Password</label>
                                    <div style={{ position: 'relative' }}>
                                        <Key size={18} style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
                                        <input
                                            type="password"
                                            required
                                            style={{ width: '100%', padding: '15px 15px 15px 45px', borderRadius: '12px', border: '1px solid #cbd5e1', fontSize: '1rem', fontWeight: 600, outline: 'none' }}
                                            placeholder="••••••••"
                                            value={currentPassword}
                                            onChange={(e) => setCurrentPassword(e.target.value)}
                                        />
                                    </div>
                                </div>

                                <div style={{
                                    display: 'grid',
                                    gridTemplateColumns: window.innerWidth <= 480 ? '1fr' : '1fr 1fr',
                                    gap: '20px'
                                }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 900, color: '#475569', textTransform: 'uppercase', marginBottom: '10px' }}>New Password</label>
                                        <input
                                            type="password"
                                            required
                                            style={{ width: '100%', padding: '15px', borderRadius: '12px', border: '1px solid #cbd5e1', fontSize: '1rem', fontWeight: 600, outline: 'none' }}
                                            placeholder="Min 6 chars"
                                            value={newPassword}
                                            onChange={(e) => setNewPassword(e.target.value)}
                                        />
                                    </div>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 900, color: '#475569', textTransform: 'uppercase', marginBottom: '10px' }}>Confirm New Password</label>
                                        <input
                                            type="password"
                                            required
                                            style={{ width: '100%', padding: '15px', borderRadius: '12px', border: '1px solid #cbd5e1', fontSize: '1rem', fontWeight: 600, outline: 'none' }}
                                            placeholder="Re-type new password"
                                            value={confirmPassword}
                                            onChange={(e) => setConfirmPassword(e.target.value)}
                                        />
                                    </div>
                                </div>

                                <div style={{ background: '#f8fafc', padding: '20px', borderRadius: '12px', border: '1px solid #e2e8f0', display: 'flex', gap: '15px', alignItems: 'flex-start' }}>
                                    <AlertCircle size={22} color="#6366f1" style={{ flexShrink: 0, marginTop: '2px' }} />
                                    <p style={{ fontSize: '0.8rem', color: '#475569', lineHeight: 1.6, fontWeight: 600 }}>
                                        <strong>Security Note:</strong> Changing your password will synchronize across all active sessions. Ensure you update it on all terminal devices.
                                    </p>
                                </div>

                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    style={{ padding: '18px', background: '#0f172a', color: 'white', border: 'none', borderRadius: '12px', fontWeight: 900, fontSize: '0.95rem', cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}
                                >
                                    {isLoading ? <Loader2 size={20} className="animate-spin" /> : "UPDATE SECURITY CREDENTIALS"}
                                </button>
                            </form>

                            <div style={{ marginTop: '50px', paddingTop: '40px', borderTop: '2px dashed #f1f5f9' }}>
                                <div style={{ marginBottom: '25px' }}>
                                    <h3 style={{ fontSize: '1.2rem', fontWeight: 900, color: '#4338ca', marginBottom: '8px' }}>Terminal Safety PIN</h3>
                                    <p style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: 600 }}>This PIN is required to leave the Sale Terminal and access the administrative Dashboard.</p>
                                </div>

                                <form onSubmit={handleUpdatePin} style={{
                                    display: 'flex',
                                    flexDirection: window.innerWidth <= 480 ? 'column' : 'row',
                                    alignItems: window.innerWidth <= 480 ? 'stretch' : 'flex-end',
                                    gap: '20px'
                                }}>
                                    <div style={{ flex: 1 }}>
                                        <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: 900, color: '#475569', textTransform: 'uppercase', marginBottom: '10px' }}>New 4-Digit Security PIN</label>
                                        <div style={{ position: 'relative' }}>
                                            <Lock size={18} style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: '#4338ca' }} />
                                            <input
                                                type="password"
                                                maxLength={4}
                                                style={{ width: '100%', padding: '15px 15px 15px 45px', borderRadius: '12px', border: '1px solid #cbd5e1', fontSize: '1.5rem', fontWeight: 900, letterSpacing: '8px', outline: 'none' }}
                                                placeholder="1234"
                                                value={terminalPin}
                                                onChange={(e) => setTerminalPin(e.target.value)}
                                            />
                                        </div>
                                    </div>
                                    <button type="submit" style={{ padding: '18px 35px', background: '#4338ca', color: 'white', border: 'none', borderRadius: '12px', fontWeight: 900, cursor: 'pointer', fontSize: '0.95rem' }}>
                                        SAVE PIN
                                    </button>
                                </form>
                            </div>
                        </>
                    ) : (
                        <div style={{ animation: 'fadeIn 0.3s ease' }}>
                            {/* DEVELOPED BY SECTION */}
                            <div style={{ textAlign: 'center', marginBottom: '40px', padding: '35px', background: 'linear-gradient(135deg, #0f172a, #1e293b)', borderRadius: '24px', color: 'white', position: 'relative', overflow: 'hidden', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}>
                                <div style={{ position: 'relative', zIndex: 1 }}>
                                    <div style={{ width: '70px', height: '70px', background: 'rgba(255,255,255,0.1)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px', border: '1px solid rgba(255,255,255,0.2)' }}>
                                        <ShieldCheck size={38} color='#10b981' />
                                    </div>
                                    <h4 style={{ fontSize: '0.75rem', fontWeight: 900, letterSpacing: '3px', color: '#94a3b8', marginBottom: '10px', textTransform: 'uppercase' }}>OFFICIAL SOFTWARE LICENSE</h4>
                                    <h2 style={{ fontSize: '2rem', fontWeight: 950, marginBottom: '5px' }}>Asper InfoTech <span style={{ color: '#38bdf8' }}>Private Limited</span></h2>
                                    <p style={{ fontSize: '0.9rem', fontWeight: 600, opacity: 0.8 }}>SECP Registered | PSEB Certified Enterprise Solutions</p>
                                </div>
                                <div style={{ position: 'absolute', bottom: '-20px', right: '-20px', opacity: 0.05 }}>
                                    <ShieldCheck size={200} />
                                </div>
                            </div>

                            {/* LEGAL DOCUMENT VIEWER */}
                            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '20px', overflow: 'hidden' }}>
                                <div style={{ background: 'white', padding: '15px 25px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                        <FileText size={18} color='#64748b' />
                                        <span style={{ fontSize: '0.8rem', fontWeight: 900, color: '#475569' }}>EULA DOCUMENT: AINF-EULA-MED-POS-2026-001</span>
                                    </div>
                                    <span style={{ fontSize: '0.7rem', fontWeight: 800, color: '#10b981', background: '#ecfdf5', padding: '4px 10px', borderRadius: '20px' }}>v1.0.2 STABLE</span>
                                </div>

                                <div style={{ maxHeight: '700px', overflowY: 'auto', padding: '40px', color: '#1e293b', background: '#ffffff', fontFamily: '"Courier New", monospace', fontSize: '13px', lineHeight: '1.7', whiteSpace: 'pre-wrap' }}>
                                    {EULA_CONTENT}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Settings;

const EULA_CONTENT = `════════════════════════════════════════════════════════════════════════
END-USER SOFTWARE LICENSE AGREEMENT (EULA)
TAHZEEB SWEETS & SUPER STORE — POINT OF SALE
════════════════════════════════════════════════════════════════════════

Version        : 1.0.2 Stable
Effective Date : 2026
Jurisdiction   : Islamic Republic of Pakistan

Please read this Agreement carefully before installing or using the
Software. By installing or using the Software, you ("the Licensee")
agree to be bound by the terms below. If you do not agree, do not
install or use the Software.


1. LICENSE GRANT
   The Licensee is granted a non-exclusive, non-transferable license to
   install and use this Point of Sale software for operating a single
   retail store (Tahzeeb Sweets & Super Store or the business it is
   installed for). The Software runs locally on the Licensee's own
   computer and database.

2. PERMITTED USE
   (a) Recording sales, invoices and receipts.
   (b) Managing inventory, stock, suppliers and customers.
   (c) Recording expenses, credit (khata) and daily reports.
   (d) Any normal retail / general-store business operation.

3. RESTRICTIONS
   The Licensee shall not:
   (a) Resell, rent, sub-license or distribute the Software to others.
   (b) Reverse-engineer, decompile or attempt to extract the source
       code, except as permitted by law.
   (c) Remove or alter any ownership or copyright notices.

4. DATA & PRIVACY
   All business data (sales, inventory, customers, etc.) is stored
   locally on the Licensee's own machine. The Software does not send
   business data to any external server. The Licensee is solely
   responsible for backing up its own data and for the accuracy of the
   records it enters.

5. NO WARRANTY
   The Software is provided "AS IS" without warranty of any kind. The
   developer does not warrant that the Software will be error-free or
   uninterrupted. The Licensee uses the Software at its own risk.

6. LIMITATION OF LIABILITY
   To the maximum extent permitted by law, the developer shall not be
   liable for any loss of data, loss of profit, or any indirect or
   consequential damages arising from the use of the Software.

7. TERMINATION
   This license remains in effect until terminated. It terminates
   automatically if the Licensee breaches any term of this Agreement.

8. GOVERNING LAW
   This Agreement is governed by the laws of the Islamic Republic of
   Pakistan.


By using this Software you acknowledge that you have read, understood
and agreed to this Agreement.

────────────────────────────────────────────────────────────────────────
TAHZEEB SWEETS & SUPER STORE — POINT OF SALE
© 2026 | ALL RIGHTS RESERVED
════════════════════════════════════════════════════════════════════════`;

