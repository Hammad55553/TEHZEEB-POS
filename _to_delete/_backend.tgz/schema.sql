-- ============================================================
-- Tahzeeb Sweets & Super Store - POS
-- PostgreSQL schema (fully local / offline)
-- ============================================================

-- Users (replaces Supabase Auth). Passwords hashed with bcrypt.
CREATE TABLE IF NOT EXISTS users (
    id          BIGSERIAL PRIMARY KEY,
    email       TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,               -- bcrypt hash
    name        TEXT,
    role        TEXT DEFAULT 'cashier',      -- admin | manager | cashier
    status      TEXT DEFAULT 'active',       -- active | disabled
    created_at  TIMESTAMPTZ DEFAULT now()
);

-- Inventory / products
CREATE TABLE IF NOT EXISTS inventory (
    id            BIGSERIAL PRIMARY KEY,
    name          TEXT NOT NULL,
    category      TEXT,
    barcode       TEXT,
    batch_no      TEXT,
    cost_price    NUMERIC(12,2) DEFAULT 0,
    sale_price    NUMERIC(12,2) DEFAULT 0,
    stock         NUMERIC(12,2) DEFAULT 0,
    initial_stock NUMERIC(12,2) DEFAULT 0,
    total_sold    NUMERIC(12,2) DEFAULT 0,
    unit          TEXT DEFAULT 'pcs',        -- pcs | kg | dozen | box
    low_stock     NUMERIC(12,2) DEFAULT 5,
    expiry_date   DATE,
    supplier      TEXT,
    data          JSONB DEFAULT '{}'::jsonb, -- any extra fields the UI stores
    deleted_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT now(),
    updated_at    TIMESTAMPTZ DEFAULT now()
);

-- Customers (khata / credit)
CREATE TABLE IF NOT EXISTS customers (
    id          BIGSERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    phone       TEXT,
    address     TEXT,
    balance     NUMERIC(12,2) DEFAULT 0,
    history     JSONB DEFAULT '[]'::jsonb,
    data        JSONB DEFAULT '{}'::jsonb,
    deleted_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now(),
    updated_at  TIMESTAMPTZ DEFAULT now()
);

-- Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
    id          BIGSERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    phone       TEXT,
    company     TEXT,
    balance     NUMERIC(12,2) DEFAULT 0,
    history     JSONB DEFAULT '[]'::jsonb,
    data        JSONB DEFAULT '{}'::jsonb,
    deleted_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now(),
    updated_at  TIMESTAMPTZ DEFAULT now()
);

-- Sales (a receipt / bill)
CREATE TABLE IF NOT EXISTS sales (
    id            BIGSERIAL PRIMARY KEY,
    invoice_no    TEXT,
    customer_id   BIGINT,
    customer_name TEXT,
    subtotal      NUMERIC(12,2) DEFAULT 0,
    discount      NUMERIC(12,2) DEFAULT 0,
    tax           NUMERIC(12,2) DEFAULT 0,
    total         NUMERIC(12,2) DEFAULT 0,
    paid          NUMERIC(12,2) DEFAULT 0,
    change_due    NUMERIC(12,2) DEFAULT 0,
    payment_method TEXT DEFAULT 'cash',      -- cash | card | easypaisa | jazzcash | credit
    profit        NUMERIC(12,2) DEFAULT 0,
    cashier       TEXT,
    shift_id      BIGINT,
    data          JSONB DEFAULT '{}'::jsonb,
    deleted_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT now()
);

-- Sale line items (child of sales)
CREATE TABLE IF NOT EXISTS sale_items (
    id            BIGSERIAL PRIMARY KEY,
    sale_id       BIGINT REFERENCES sales(id) ON DELETE CASCADE,
    inventory_id  BIGINT,
    name          TEXT,
    qty           NUMERIC(12,2) DEFAULT 1,
    price         NUMERIC(12,2) DEFAULT 0,
    cost_price    NUMERIC(12,2) DEFAULT 0,
    total         NUMERIC(12,2) DEFAULT 0,
    data          JSONB DEFAULT '{}'::jsonb
);

-- Expenses
CREATE TABLE IF NOT EXISTS expenses (
    id          BIGSERIAL PRIMARY KEY,
    title       TEXT,
    category    TEXT,
    amount      NUMERIC(12,2) DEFAULT 0,
    note        TEXT,
    data        JSONB DEFAULT '{}'::jsonb,
    deleted_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now()
);

-- Shifts (cash register open/close)
CREATE TABLE IF NOT EXISTS shifts (
    id            BIGSERIAL PRIMARY KEY,
    cashier       TEXT,
    opening_cash  NUMERIC(12,2) DEFAULT 0,
    closing_cash  NUMERIC(12,2),
    total_sales   NUMERIC(12,2) DEFAULT 0,
    status        TEXT DEFAULT 'open',       -- open | closed
    data          JSONB DEFAULT '{}'::jsonb,
    opened_at     TIMESTAMPTZ DEFAULT now(),
    closed_at     TIMESTAMPTZ
);

-- Shortage book (items short at counter)
CREATE TABLE IF NOT EXISTS shortage (
    id            BIGSERIAL PRIMARY KEY,
    name          TEXT,
    inventory_id  BIGINT,
    qty           NUMERIC(12,2) DEFAULT 0,
    note          TEXT,
    resolved      BOOLEAN DEFAULT false,
    data          JSONB DEFAULT '{}'::jsonb,
    created_at    TIMESTAMPTZ DEFAULT now()
);

-- Supply orders to suppliers
CREATE TABLE IF NOT EXISTS orders (
    id            BIGSERIAL PRIMARY KEY,
    supplier      TEXT,
    supplier_id   BIGINT,
    items         JSONB DEFAULT '[]'::jsonb,
    total         NUMERIC(12,2) DEFAULT 0,
    status        TEXT DEFAULT 'pending',    -- pending | received | cancelled
    notes         TEXT,
    data          JSONB DEFAULT '{}'::jsonb,
    deleted_at    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_inventory_deleted ON inventory(deleted_at);
CREATE INDEX IF NOT EXISTS idx_sales_deleted     ON sales(deleted_at);
CREATE INDEX IF NOT EXISTS idx_sale_items_sale   ON sale_items(sale_id);
CREATE INDEX IF NOT EXISTS idx_customers_deleted ON customers(deleted_at);
